<?php
$con=mysqli_connect("localhost","root","","foodu");
if(!$con){
    echo 'not connected';

}
else{
    echo '';
}?>